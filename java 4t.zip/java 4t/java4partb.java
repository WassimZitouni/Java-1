import javax.swing.JOptionPane;

public class java4partb 
{
    public static void main(String[] args) 
    {
    // Ask for gross income
        String incomeInput = JOptionPane.showInputDialog("Please enter your gross income:");
        double grossIncome = Double.parseDouble(incomeInput);
        calculateNetIncome(grossIncome);
        System.exit(0);
    }
    // Method 1: Calculate net income
    public static void calculateNetIncome(double grossIncome) 
    {
        double taxRate = findTaxRate(grossIncome); 
        double taxAmount = grossIncome * taxRate;
        displayPaycheckAmount(grossIncome, taxAmount); 
    }
    // Method 2: Find tax rate 
    public static double findTaxRate(double income) 
    {
        if (income <= 50000) 
        {
            return 0.10; // 10%
        } else if (income <= 120000) 
        {
            return 0.15; // 15%
        } else {
            return 0.20; // 20%
        }
    }
    // Method 3: show the income, tax amount, and net income
    public static void displayPaycheckAmount(double income, double taxAmount) 
    {
        double paycheckAmount = income - taxAmount;
        String message = String.format(
            "<html>Income Amount: $%,.2f<br>Tax Amount: $%,.2f<br>Paycheck Amount: $%,.2f</html>",
            income, taxAmount, paycheckAmount
        );
        JOptionPane.showMessageDialog(null, message);
    }
}