import java.util.Scanner;

public class java4partc
{
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        // Get gross income,exemptions,state code
        System.out.print("Enter your annual income: ");
        double annualIncome = scanner.nextDouble();
        System.out.print("Enter the number of exemptions: ");
        int exemptions = scanner.nextInt();
        System.out.print("Enter your state (NC, ND, or LA): ");
        String stateCode = scanner.next().toUpperCase();
        // Calculate tax
        double stateTax = calculateStateTax(annualIncome, exemptions, stateCode);
        String stateName = getStateName(stateCode);
        // Get state name
        printTaxInfo(stateCode, stateName, annualIncome, stateTax);
        scanner.close();
    }
    // Calculate state tax
    public static double calculateStateTax(double income, int exemptions, String state) 
    {
        switch (state)
         {
            case "NC":
                return calculateNCTax(income, exemptions);
            case "ND":
                return calculateNDTax(income, exemptions);
            default:
                System.out.println("Invalid state code.");
                return 0.0;
        }
    }
// Calculate NC tax
    public static double calculateNCTax(double income, int exemptions) 
    {
        double taxableAmount = Math.max(0, income - (exemptions * 2500) - 12750);
        return taxableAmount * 0.046;
    }
    // Calculate ND tax
    public static double calculateNDTax(double income, int exemptions) 
    {
        double taxableAmount = Math.max(0, income - (exemptions * 4300) - 52025);
        // Apply tax rate
        return taxableAmount <= 181250 ? taxableAmount * 0.0195 : taxableAmount * 0.025;
    }
    // Get state name
    public static String getStateName(String stateCode) 
    {
        switch (stateCode) 
        {
            case "NC":
                return "North Carolina";
            case "ND":
                return "North Dakota";
            case "LA":
                return "Louisiana";
            default:
                return "Unknown";
        }
    }
    // Show tax information
    public static void printTaxInfo(String stateCode, String stateName, double income, double tax) 
    {
        System.out.printf("State: %s (%s)\nAnnual Income: $%,.2f\nState Tax: $%,.2f\n",
                          stateName, stateCode, income, tax);
    }
}